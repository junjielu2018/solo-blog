title: frp内网穿透，ssh访问内网服务器
date: '2019-08-18 12:26:44'
updated: '2019-08-18 12:26:58'
tags: [Linux]
permalink: /articles/2019/08/18/1566102404043.html
---
## 准备工作

1. 下载对应的版本
https://github.com/fatedier/frp/releases

2. 保证服务器ssh服务正常开启
` #systemctl enable sshd.service  //开机启动`
` #systemctl status sshd.service   //服务状态`
` #systemctl start sshd.service     //启动服务`

## 开始使用

* 将 **frps** 及 **frps.ini** 放到具有公网 IP 的机器上。
``` 修改 frps.ini 文件
# frps.ini
[common]
bind_port = 7000

启动 frps：
./frps -c ./frps.ini
```
* 将 **frpc** 及 **frpc.ini** 放到处于内网环境的机器上。
```
# frpc.ini
[common]
server_addr = x.x.x.x
server_port = 7000

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
启动 frpc：
./frpc -c ./frpc.ini
```

## 通过 ssh 访问内网机器
`ssh -p 6000 root@server_addr`

