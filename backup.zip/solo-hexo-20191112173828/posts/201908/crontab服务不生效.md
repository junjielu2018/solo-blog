title: crontab服务不生效
date: '2019-08-22 07:52:42'
updated: '2019-08-22 07:56:21'
tags: [Linux]
permalink: /articles/2019/08/22/1566431562617.html
---
装完manjaro之后，发现crontab设置之后不生效

```
1.执行 systemctl status crond
Unit crond.service could not be found.
```



实际上cron服务被重命名了...
```
尝试执行 systemctl start cronie
服务能用了
```

	参考地址：https://stackoverflow.com/questions/43257021/start-crond-service-on-ubuntu-16-04
