title: docker环境搭建 docker下安装mysql 宿主端口映射
date: '2019-08-16 20:01:52'
updated: '2019-08-16 22:20:27'
tags: [Linux]
permalink: /articles/2019/08/16/1565956912518.html
---
1.安装docker 
`yum install -y docker`
2.配置docker源
`
vim /etc/docker/daemon.json
`

```

{

"registry-mirrors": ["http://hub-mirror.c.163.com"]

}
```

3.为普通用户赋予docker权限

`sudo usermod -aG docker username`

4.docker中安装mysql

`docker pull mysql/mysql-server:5.7`

`docker images`

`docker run --name=mysql1 -e MYSQL_ROOT_PASSWORD=111111 -p 13306:3306 -d mysql/mysql-server:5.7`

`docker exec -it mysql1 mysql -uroot -p`

`update user set host='%' where user='root';`

`flush privileges;`

启动通过：`docker start mysql1`

4.查看端口是否启用
`netstat -tulpn`
